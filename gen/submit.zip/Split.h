#ifndef SPLIT_H
#define SPLIT_H

#include "Mini.h"

/*
struct Block {
	vector<Instr&> instr;

	Block& t;
	Block& f;

	Block();

	Instr* entry();
	Instr* exit();
};

typedef map<string, Block> functions;

functions split(procedures&);
*/

#endif